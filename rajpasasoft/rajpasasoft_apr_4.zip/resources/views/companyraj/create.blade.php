<h2 class="page-header">New Company</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("companyraj._form")
{!! Form::close() !!}