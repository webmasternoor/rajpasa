<h2 class="page-header">Edit Division</h2>
{!! Form::model($division,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("division._form")
{!! Form::close() !!}