<?php

return [

	'getBasic.title' => 'Html Builder via Dependency Injection',
	'getBasic.description' => 'Laravel Datatables Html Builde Demo',

	'getIndex.title' => 'Html Builder Notes',
	'getIndex.description' => 'Laravel Datatables Html Builde Demo',

	'getMethod.title' => 'Html Builder via Method Injection',
	'getMethod.description' => 'Laravel Datatables Html Builde Demo',

	'getColumns.title' => 'Html Builder with Plain Columns',
	'getColumns.description' => 'Laravel Datatables Html Builde Demo',

];
