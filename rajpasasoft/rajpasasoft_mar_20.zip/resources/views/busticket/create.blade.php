<h2 class="page-header">bus Search</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("busticket._form")
{!! Form::close() !!}