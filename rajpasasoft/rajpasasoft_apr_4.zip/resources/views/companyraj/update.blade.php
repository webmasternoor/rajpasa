<h2 class="page-header">Edit Companyraj</h2>
{!! Form::model($companyraj,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("companyraj._form")
{!! Form::close() !!}