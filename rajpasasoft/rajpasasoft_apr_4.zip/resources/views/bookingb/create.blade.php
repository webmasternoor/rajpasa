@if (Auth::guest())

@else

<h2 class="page-header">New Bookingb</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("bookingb._form")
{!! Form::close() !!}
@endif