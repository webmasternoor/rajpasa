<h2 class="page-header">New Counter</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("counter._form")
{!! Form::close() !!}