<h2 class="page-header">Edit Busraj</h2>
{!! Form::model($bussearch,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("bussearch._form")
{!! Form::close() !!}