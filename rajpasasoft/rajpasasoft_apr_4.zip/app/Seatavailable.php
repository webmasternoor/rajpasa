<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Seatavailable extends Model
{

}