<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Laun extends Model
{

}