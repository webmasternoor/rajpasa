@if (Auth::guest())

@else

<h2 class="page-header">Edit Bookingb</h2>
{!! Form::model($bookingb,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("bookingb._form")
{!! Form::close() !!}
@endif