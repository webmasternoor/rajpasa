@if (Auth::guest())

@else

<h2 class="page-header">New Bookinghotel</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("bookinghotel._form")
{!! Form::close() !!}
@endif