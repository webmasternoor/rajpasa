<h2 class="page-header">New Companyraj</h2>
{!! Form::open(["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("companyraj._form")
{!! Form::close() !!}