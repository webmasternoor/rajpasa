<h2 class="page-header">Edit Busraj</h2>
{!! Form::model($busraj,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("busraj._form")
{!! Form::close() !!}