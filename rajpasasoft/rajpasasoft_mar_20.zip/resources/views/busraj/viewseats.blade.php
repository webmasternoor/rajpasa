<h2 class="page-header">Seat View</h2>
{!! Form::model($busraj,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("busraj._seat")
{!! Form::close() !!}