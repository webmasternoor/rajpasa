<h2 class="page-header">Edit District</h2>
{!! Form::model($district,["id"=>"frm","class"=>"form-horizontal"]) !!}
@include("district._form")
{!! Form::close() !!}