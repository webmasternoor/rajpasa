<h2 class="page-header">Seat View</h2>

@include("busraj._seat")
