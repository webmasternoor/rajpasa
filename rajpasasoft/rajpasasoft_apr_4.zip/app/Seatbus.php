<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Seatbus extends Model
{

}